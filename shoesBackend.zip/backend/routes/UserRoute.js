const express = require('express');
const router = express.Router();
const { authController, getuserProfile } = require('../controllers/userController')
const { protect } = require('../middlewares/authMiddleware')

// post email and password auth
router.post('/login', authController)

// get user profile Private Route
router.route("/profile").get(protect, getuserProfile)

module.exports = router;