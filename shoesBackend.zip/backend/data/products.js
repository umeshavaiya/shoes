const products = [{
    name: 'Nike e2210Q ',
    image: '/images/orange.png',
    description: 'boAt Airdopes 121v2 TWS Earbuds with Bluetooth v5.0, Immersive Audio, Up to 14H Total Playback, Instant Voice Ass',
    brand: 'Boat',
    category: 'Casual',
    price: 5*.99,
    countInStock: 0,
    rating: 4.5,
    numReviews: 12
}, {
    name: 'Puma A1009',
    image: '/images/mensblue.png',
    description: 'Say hello to the Micromax IN 1b smartphone whose powerful MediaTek Helio G35 gaming processor and a 5000 mAh batt',
    brand: 'Micromax',
    category: 'Sports',
    price: 5990.99,
    countInStock: 7,
    rating: 4.0,
    numReviews: 8,
}, {
    name: 'Adda N-342',
    image: '/images/mensblue.png',
    description: 'Say hello to the Micromax IN 1b smartphone whose powerful MediaTek Helio G35 gaming processor and a 5000 mAh batt',
    brand: 'Micromax',
    category: 'Running',
    price: 125.99,
    countInStock: 7,
    rating: 4.0,
    numReviews: 8,
}, {
    name: 'HRX by-8943',
    image: '/images/mensblue.png',
    description: 'Say hello to the Micromax IN 1b smartphone whose powerful MediaTek Helio G35 gaming processor and a 5000 mAh batt',
    brand: 'Micromax',
    category: 'Gym',
    price: 512.99,
    countInStock: 7,
    rating: 4.0,
    numReviews: 8,
}, {
    name: 'Adidas PM-35T',
    image: '/images/mensblue.png',
    description: 'Say hello to the Micromax IN 1b smartphone whose powerful MediaTek Helio G35 gaming processor and a 5000 mAh batt',
    brand: 'Micromax',
    category: 'Party',
    price: 689.99,
    countInStock: 7,
    rating: 4.0,
    numReviews: 8,
}]


module.exports = products